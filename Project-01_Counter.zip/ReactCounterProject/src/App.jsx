import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  let [count, setCount] = useState(0)

  function increaseValue(){
    count = count+1;
    setCount(count);

    if (count>20) {
      alert(`you cannot go beyond the count: ${count-1}`)
    }
  }

  function decreaseValue(){
    count = count-1;
    setCount(count);
    if (count<0) {
      alert("You cannot go below this count")
    }
  }

  return (
    <>
    <img src="https://media2.dev.to/dynamic/image/width=1080,height=1080,fit=cover,gravity=auto,format=auto/https%3A%2F%2Fdev-to-uploads.s3.amazonaws.com%2Fuploads%2Farticles%2F096baapsqqt9fks0us99.png" 
    alt="React Counter Image:" />
      <h1>COUNTER USING THE REACT</h1>

      <h2>The current count is: {count} </h2>

      <button onClick={increaseValue}>Increase Value</button>
      <br /><br />
      <button onClick={decreaseValue}>Decrease Value</button>
    </>
  )
}

export default App
