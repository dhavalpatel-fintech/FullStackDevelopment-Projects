import './App.css'
// need to import the Chai file in the App.jsx
import Chai from './Chai'


function App() {

  return (
    <>
      <h1>Hello Duniya, I am Dhaval Patel, welcome to the chai with confidence</h1>
      <p>
        you can make a comment in the react using the // just like you did in the JavaScript
      </p>
      {/* inside the <> only */}

      <Chai/>
    </>
  )
}

export default App
