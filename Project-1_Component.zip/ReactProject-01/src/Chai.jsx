

// making the new COMPONENT called the "Chai.jsx"
// Here the React have some of the restrictions so called the 
// 1. You need to save the file using the proper ".jsx"
// 2. the component name should be in the Uppercase
// 3. inside the App.jsx you have to add only one Tag


function Chai(){
    return(
        <h1>Hello Miss, Your Chai is ready!</h1>
    )
}

// need to export the current file and need to import the same file in the App.jsx
export default Chai;
